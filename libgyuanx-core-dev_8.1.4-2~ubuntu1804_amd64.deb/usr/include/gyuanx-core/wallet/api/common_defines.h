#ifndef WALLET_API_COMMON_DEFINES_H__
#define WALLET_API_COMMON_DEFINES_H__

#define tr(x) (x)

#endif

